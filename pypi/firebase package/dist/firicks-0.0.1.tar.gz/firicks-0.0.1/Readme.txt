firebase push and pull dictionary
